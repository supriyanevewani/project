export class Criteria {

    constructor(
        public from:string,
        public to:string,
        public departureDate:string) {  }
  
  }