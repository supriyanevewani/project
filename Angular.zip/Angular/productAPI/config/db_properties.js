module.exports = {
    host:"localhost",
    user:"root",
    password:"test",
    database:"mydb"
}