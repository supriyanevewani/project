import { MyLoopDirective } from './my-loop.directive';

describe('MyLoopDirective', () => {
  it('should create an instance', () => {
    const directive = new MyLoopDirective();
    expect(directive).toBeTruthy();
  });
});
