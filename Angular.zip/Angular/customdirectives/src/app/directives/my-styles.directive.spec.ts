import { MyStylesDirective } from './my-styles.directive';

describe('MyStylesDirective', () => {
  it('should create an instance', () => {
    const directive = new MyStylesDirective();
    expect(directive).toBeTruthy();
  });
});
